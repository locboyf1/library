package com.library.project.vinhuni.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.project.vinhuni.entity.Sach;

// 1. ĐỔI "String" thành "Long" ở dòng dưới
public interface SachIRepository extends JpaRepository<Sach, Long> {

	// 2. ĐỔI "String maSach" thành "Long maSach" ở dòng dưới
	public Sach findByMaSach(Long maSach);
}